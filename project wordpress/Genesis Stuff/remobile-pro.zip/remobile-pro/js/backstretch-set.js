jQuery(document).ready(function($) {
	$(".home-intro").backstretch([BackStretchImg.src],{duration:3000,fade:750});
});