REMOBILE PRO THEME
http://my.studiopress.com/themes/remobile/

INSTALL
1. Upload the Remobile Pro theme folder via FTP to your wp-content/themes/ directory. (The Genesis parent theme needs to be in the wp-content/themes/ directory as well.)
2. Go to your WordPress dashboard and select Appearance.
3. Activate the Remobile Pro theme.
4. Inside your WordPress dashboard, go to Genesis > Theme Settings and configure them to your liking. To set up the theme like the demo, please visit http://my.studiopress.com/setup/remobile-theme/.

WIDGET AREAS
Home Intro - This is the home intro section.
Home Pricing - This is the home pricing section.
Home Features - This is the home features section.
Home Twitter - This is the home Twitter section.
After Entry - This is the widget that appears after the entry on single posts.
Footer #1 - This is the first column of the footer section.
Footer #2 - This is the second column of the footer section.
Footer #3 - This is the third column of the footer section.

ENTRY BACKGROUND IMAGES
The optimal size for an entry background image is 1600px by 558px.
The entry background images that were used in the Remobile Pro theme demo are courtesy http://www.gratisography.com/.

SUPPORT
Please visit http://my.studiopress.com/help/ for theme support.

CHANGELOG

= 1.0 =
* Initial release